function [x,amp,hstretch,sun,light,score,numberofcircles,highscore,finish,sounds] = startup()
% This function handles the start of the game. It initializes all the
% variables needed for the rest of the game, and returns them to the main.
% It also handles the intro animations and title screen.
    
    % Clear the command window, turn the hold for plots off and axis off,
    % turn sound off, and close all figure windows
    close all
    clear
    clear sound
    clc
    hold off
    axis off

    % Initialize variables
    numberofcircles = 0; % Start off with 0, increments to 1 before spawning
    amp = 2; % Initial amplitude of the sin wave
    hstretch = 1; % Initial horizontal stretch of the sin wave
    x = 0:1/20:10; % The x-step for the sin wave. 200 points to ensure smoothness
    score = 0; % Initial score is 0 obviously
    finish = false; % The variable to keep the while loop running
    
    % Check for any existing highscores
    % 'fopen' returns -1 if file does not exist
    highscore_file_exists = fopen('highscore.txt');
    highscore = 0;
    % If it doesn't exist
    if highscore_file_exists == -1
        % Create a file and put 0 into it
        save highscore.txt highscore
    end
    % If it exists, load the highscore (If it didn't exist before, it's 0)
    load highscore.txt -mat highscore
    
    sun = imread('sun.png'); % Import the sun image from folderAY
    light = imread('light.png'); % Import the light image from folder

    % Import Sound
    [bgm_y, bgm_Fs] = audioread('AversionSoundtrack.mp3');
    [go_y, go_Fs] = audioread('Travel.mp3');
    [hit_y, hit_Fs] = audioread('Hit.mp3');
    
    % Store sound data to a cell array
    sounds = {bgm_y bgm_Fs go_y go_Fs hit_y hit_Fs};
    
    % Play background music at 20% volume
    sound(0.2*bgm_y,bgm_Fs);
     
    % Set the color of the figure to black (outside the graph area)
    set(gcf,'color','k');
    % Set the color of the axis to black (the area where the graphs are)
    set(gca,'Color','k')
    % Hide the toolbar
    set(gcf,'menubar','none')
    % Change the title of the window to the title of the game and turn the
    % 'Figure 1' thing off
    set(gcf,'Name','Aversion v1.0','NumberTitle','off')
    
    
    
    % This section is responsible for the title screen
    % Creates a text object with the text 'Aversion'. The first two numbers 
    % are x and y position of the text. The other properties
    % are listed as 'Property', 'Value'. Ex: 'Color', 'white'
    text(0.5, 0.9, 'Aversion','FontSize', 50,'Color', 'white','HorizontalAlignment','center','FontName','FixedWidth');
   
    % A cell array consisting of everything below the title on the title
    % screen. The cell array allows for multi-line display.
    str = {'You are LIGHT', '', 'Use WASD/Arrow keys to move','Press the spacebar to travel','Asteroids move when you do', 'Good luck', '', 'Press any key to continue'};
    
    % Text object to display the cell array
    text(0.5, 0.4, str,'FontSize', 20,'Color', 'white','HorizontalAlignment','center','FontName','FixedWidth');
  
    % Wait for the player to press a key, then continue
    waitforbuttonpress;

    % Show the sun image loaded earlier, at a 67% magnification because the
    % original file is pretty large
    imshow(sun,'InitialMagnification',67);
    
    % The length of this for loop controls how long and how fast the
    % animation proceeds (where the light exits the sun)
    for i = 1:35
        
        % Make the light a tiny bit smaller each time
        light = imresize(light, 1-(i/900));
        
        % Call the function which draws the animation, and pass it the
        % light and sun images as well as the for loop index
        draw_light_initial(i, sun, light);
        
    end

    % Record the value of the current axes, so that we can display an image
    % on another set of axes
    masteraxes = axes;
    
    % This is the animation when the light is coming from the left side
    for i = 1:10
        
        % Set the color of the axes to black
        set(gca,'Color','k')
        
        % Change the position of the axes every loop
        % This doesn't change the range of the axis, but literally the position
        % of the axes (think of the x and y-axis moving)
        temp_axes = axes('Position',[-0.07+(i/100) 0.47 0.1 0.1]);
        
        % Display the light image onto the axes
        image(temp_axes,0,250,light);
        
        % Pause to seem like an animation
        pause(0.08)
        
        % Delete the axes, since we either move these ones or switch back to
        % the other axes
        delete(gca);

    end
    
    % Swtich back to the original axes
    axes(masteraxes);
    
    % Plot the white dotted sin wave graph
    plot(x, amp*sin(hstretch*x),'w.');
    
    % The range for the axis we use for the game
    axis([0 10 -5 5]); 
    
    % Make the game fullscreen
    set(gcf,'WindowState','fullscreen') 
    
    % Set the axes to full screen
    set(gca,'Unit','normalized','Position',[0 0 1 1]);
    
    % Set the color of the axis to black (the area where the graphs are)
    set(gca,'Color','k')

end