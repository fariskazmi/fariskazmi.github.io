function trail(x,amp,hstretch,i,color)
% Plots the trail as 6 consecutive points on the sin graph for the
% animation.
% Accepts the property of sin wave, 'i' -index of where the light is, and
% color (red or white).

    % The marker is set according to the color inputted
    marker = [color '*'];

    % Plots 6 points of decreasing size to illustrate a trail of light
    plot(x(i+5),amp*sin(hstretch*x(i+5)),marker,'MarkerSize',20)
    
    % Hold is set to on after the first point in order to overwrite the
    % previous trail.
    hold on
    plot(x(i+4),amp*sin(hstretch*x(i+4)),marker,'MarkerSize',16)
    plot(x(i+3),amp*sin(hstretch*x(i+3)),marker,'MarkerSize',12)
    plot(x(i+2),amp*sin(hstretch*x(i+2)),marker,'MarkerSize',8)
    plot(x(i+1),amp*sin(hstretch*x(i+1)),marker,'MarkerSize',4)
    plot(x(i),amp*sin(hstretch*x(i)),marker,'MarkerSize',1)

end