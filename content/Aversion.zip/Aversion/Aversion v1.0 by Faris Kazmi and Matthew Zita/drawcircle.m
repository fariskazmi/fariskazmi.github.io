function drawcircle(x,y,r)
% Function that plots circles
% Accepts x and y values and radius of each circle

% Draws circles without erasing previous circles
hold on

theta = linspace(0,2*pi,101);

% Plots circles in polar coordinates (x = rcos, y = rsin) around each x and
% y position of the center of the circle with a red, circle marker.
xunit = r * cos(theta) + x;
yunit = r * sin(theta) + y;
plot(xunit, yunit,'ro');

% Sets hold back to off
hold off

end