%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AVERSION v1.0
%
% By: Faris Kazmi and Matthew Zita
% 
% Acknowledgements: 
% 
% Almost all code was written independantly, with most extra knowledge coming
% from MATLAB's documentation and some from online
% 
% 
% Description:
% A game where you control the path of light to avoid asteroids!
% This game is optimized for high-end systems.
%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Tip: Just pretend the circles are asteroids to immerse yourself more

% Handle the start of the game
% The startup function returns all parameters that are needed
% The variables are then passed onto other functions
[x,amp,hstretch,sun,light,score,numberofcircles,highscore,finish,sounds] = startup();

% This is the main game loop
% Loops every time the player decides on the path for the light to take and
% stops when they press 'Esc' on a death screen
while ~finish
    
     % Calls the function 'generateasteroid' and passes the number of
     % circles that exist. The number starts at 0, but increments to 1
     % before the first level.
     
     % The x and y coordinates of the circles are returned, as well as the
     % radius of the circles, and the number of circles
     [circlex, circley, radius, numberofcircles] = generateasteroid(numberofcircles);
     
     % Calls the function 'movement' and passes parameters that affect the
     % sin function, as well as the location of the circles
     % Amp = Amplitude
     % hstretch = Horizontal Stretch
     % x = x position of the light
     % Returns altered amplitude and horizontal stretch
     [amp, hstretch,score,circlex,circley,numberofcircles,finish] = movement(amp, hstretch, x, circlex, circley,score,highscore,numberofcircles,sounds);
     
     if finish
        delete(gcf)
        break
     end
     
     % Function to check for collisions, passes coordinates of circles and
     % parameters of the sin function.
     if numberofcircles ~= 0
        [hit,score,highscore,numberofcircles,finish] = check_for_collision(circlex,circley,radius, amp, hstretch, x,score,highscore,numberofcircles,sounds);
     end
     
end