function [amp, hstretch, score, circlex, circley, numberofcircles, finish] = movement(amp, hstretch, x, circlex, circley, score, highscore, numberofcircles, sounds)
% Adjusts the path of light based on amplitude and horizontal stretch of
% the sine graph. These are controlled by WASD/Arrow keys.
% Accepts properties of the sin wave, asteroids, scores, and sounds

% Initialize 'finish' and 'key'
finish = false;
key = 0;

% Replays background music at the beginning of each round
clear sound
sound(0.2*sounds{1},sounds{2})

% Loops while the player has not pressed the space key
while ~strcmp(key,'space')
     
    % Repeats for the number of asteroids
     for i = 1:length(circlex)
         
         % Checks if any of the asteroids have passed the left side of the screen
         if(circlex(i)<0)
            
            [finish, numberofcircles, score] = deathevent(highscore); % Call the death function
            
         end
         
     end
     
    % Move the circles across the screen
    circlex = circlex - 0.1;
    
    % Redisplays all objects back to the screen
    redraw(x,amp,hstretch,circlex,circley,score,highscore,true);
    
    % If they have not died...
    if ~finish && numberofcircles ~= 0
    
    % Wait for player to press key
    waitforbuttonpress;
    
    % Store key
    key = get(gcf,'CurrentKey'); 
    
     % If the player presses 'w' or 'uparrow'
     if strcmp(key,'w') || strcmp(key,'uparrow')
         
         % Constraints the amplitude to the height of the screen
         if amp < 4.7
             
              % Adjust the amplitude by 0.3 units
              amp = amp + 0.3;

         end
         
     end
     
     % If the player presses 's' or 'downarrow'
     if strcmp(key,'s') || strcmp(key,'downarrow')
         
         % Constraints the amplitude to the height of the screen
         if amp > -4.7
         
             % Adjust the amplitude by 0.3 units
             amp = amp - 0.3;
             
         end
         
     end
     
     % If the player presses 'a' or 'leftarrow'
     if strcmp(key,'a') || strcmp(key,'leftarrow')
         
         % Constraints the horizontal stretch
         if hstretch < 2
             
             % Adjust the horizontal stretch by 0.07 units
             hstretch = hstretch + 0.07;
         
         end
         
     end
     
     % If the player presses 'd' or 'rightarrow'
     if strcmp(key,'d') || strcmp(key,'rightarrow')
         
         % Constraints the horizontal stretch
         if hstretch > 0.3
         
            % Adjust the horizontal stretch by 0.07 units
            hstretch = hstretch - 0.07;
         
        end  
         
     end
     
    
    else
        
        % Escapes the while loop if the player has died
        break
        
    end
     
end

% Plays the light travel sound
sound(sounds{3},0.9*sounds{4})

end