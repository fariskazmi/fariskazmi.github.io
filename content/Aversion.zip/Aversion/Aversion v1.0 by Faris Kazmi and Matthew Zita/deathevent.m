function [finish, numberofcircles, score] = deathevent(highscore)
% This function handles what happens when you let a circle all the way
% across or hit a circle. Returns finish depending on if the player presses
% escape.
% Accepts highscore

% Sets score to 0
score = 0;

% Saves highscore to a textfile
save highscore.txt highscore

% Sets number of circles to 0
numberofcircles = 0;

finish = false; % Doesn't change unless player presses Esc

% Create a text object saying 'YOU HAVE DIED'. Other properties were mentioned
% previously
text(5, 3, 'YOU HAVE DIED','FontSize', 75,'Color', 'red','HorizontalAlignment','center','FontName','FixedWidth'); 
str = {'Press any key to restart', ' ', ' ',' ', ' ', 'Press Esc to quit'};
text(5, -1.0, str,'FontSize', 35,'Color', 'red','HorizontalAlignment','center','FontName','FixedWidth'); 

% Wait for the player to press a button
waitforbuttonpress;

% Record the key pressed
key = get(gcf, 'CurrentKey');

% If they pressed Esc, quit the program
if strcmp(key,'escape')
    
    % Deletes the current figure
    delete(gcf)
    finish = true;
    
    % Turn off all sound and music
    clear sound
    
end

end