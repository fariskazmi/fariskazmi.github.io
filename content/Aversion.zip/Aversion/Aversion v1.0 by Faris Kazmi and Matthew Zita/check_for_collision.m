function [hit, score,highscore,numberofcircles,finish] = check_for_collision(circlex, circley, radius, amp, hstretch, x, score, highscore, numberofcircles, sounds)
% Checks whether the path of light passes through any of the asteroids.
% Accepts properties of asteroids, sin wave, scores, and sounds.

% Initialize 'finish' and 'hit'
% 'hit_index' locates where the path of light first hits an asteroid. It is
% set to -5 initially, so that if the path never goes through an asteroid,
% the light will travel through the path successfully.
finish = false;
hit = false;
hit_index = -5;

% set 'theta' for circular hitboxes
theta = linspace(0,2*pi,101);

% Repeats for the number of asteroids
for i=1:length(circlex)
    
    % As soon as we find a point that hits an asteroid, we break out of the
    % loop that checks for more collision points.
    if hit
        break
    end
    
    xunit = radius * cos(theta) + circlex(i);
    yunit = radius * sin(theta) + circley(i);
    
    % Repeats for the number of data points of light
    for j=1:length(x)
        
        % As soon as we find a point that hits an asteroid, we break out of the
        % loop that checks for more collision points.
        if hit
            break
        end
        
        % Repeats for 0 to pi rad to create a circular hitbox.
        for k=1:50
        
            % Checks whether the light passes within the radius of the asteroid
            if xunit(52-k) <= x(j) && x(j) <= xunit(k) && ...
                    yunit(102-k) <= amp*sin(hstretch*x(j)) && amp*sin(hstretch*x(j)) <= yunit(k)
                
                % 'hit' is true if any of the point on the sin graph is
                % inside an asteroid.
                hit = true;
                
                % Sets 'hit_index' to 'j'
                hit_index = j;
                
                break
                
            end
        
        end
        
    end
    
end

% Calls the 'travel' function show the light traveling
travel(amp, hstretch, x, hit_index, circlex, circley, score, highscore, sounds)

% Update the score
if ~hit
    
    % Increment score by 5 if the light does not hit the asteroids
    score = score + 5;
    
    % Only update highscore if score is greater than the highscore
    if score > highscore
        
        highscore = highscore + 5;
        save highscore.txt highscore
        
    end
    
else
    
    [finish, numberofcircles, score] = deathevent(highscore); % Call the death function
    
end

end