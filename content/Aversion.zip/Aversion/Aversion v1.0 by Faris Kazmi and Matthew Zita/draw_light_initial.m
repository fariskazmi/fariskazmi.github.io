function draw_light_initial(i, sun, light)
% This function draws the light crossing the sun
% Accepts the index and sun and light image
% Much of the content here was inspired from reading through MATLAB forums
    
    % Initially set the final image to the sun
    final_image = sun;
    
    % Initialize the horizontal path the light will take
    horizontal_shift = 500 + (i*4);
    
    % Initialize the vertical path the light will take
    % These values look best, no formula
    vertical_shift = 500+i*24;
    
    % Overlap the images, shift the image of the light across the sun
    % MATLAB stores images in a matrix, where each element corresponds to a
    % single pixel in the image. Therefore we can change elements inside
    % that matrix to suit our needs, which is what we do here.
    
    % We import the light and sun images as png files, meaning they have an
    % alpha layer embedded. We don't care about this, we only care about
    % the length and width of the image. This explains the size(light,1)
    
    % In essence, we replace a chunk in the sun image with the light image.
    % The image appears to move across the screen because the horizontal
    % and vertical shift change with each index in the for loop that calls
    % this function
    final_image((1:size(light,1))+horizontal_shift, (1:size(light,2))+vertical_shift, :) = light;
    
    % Displays the updated image
    image(final_image);
    
    % Move the axis limits so it looks like the sun is moving too 
    axis([10*i 1500+10*i 0 1600]);
    pause(0.03);
    
end