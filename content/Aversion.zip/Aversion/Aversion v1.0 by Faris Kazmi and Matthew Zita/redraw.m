function redraw(x,amp,hstretch,circlex,circley,score,highscore,ispath)
% Redisplays all objects back to the screen
% Accepts properties of light, asteroids, scores, and 'ispath'
% 'ispath' is true when player is adjusting the path. 'ispath' is false
% during the travel animation.

    % Redraws the sin wave only if 'ispath' is true
    if ispath
        
        plot(x, amp*sin(hstretch*x),'w.');
        
    end
    
    % Reset axis and the black axes
    axis([0 10 -5 5]);
    set(gca,'Color','k')
    
    % Redraws the asteroids
    for i = 1:length(circlex)
        drawcircle(circlex(i), circley(i), 0.3);
    end
    
    % Logo/Background
    text(0, 4.6, 'Aversion v1.0', 'Color', 'red', 'FontSize', 20,'FontWeight', 'bold','FontName','FixedWidth');

    % Scores
    text(0, 4.3, 'Score:','FontSize', 18,'Color', 'red','FontName','FixedWidth'); % Score
    text(0, 4.06, num2str(score),'FontSize', 18,'Color', 'red','FontName','FixedWidth'); % Score
    text(0, 3.7, 'Highscore:','FontSize', 18,'Color', 'red','FontName','FixedWidth'); % Highscore
    text(0, 3.46, num2str(highscore),'FontSize', 18,'Color', 'red','FontName','FixedWidth'); % Highscore

end