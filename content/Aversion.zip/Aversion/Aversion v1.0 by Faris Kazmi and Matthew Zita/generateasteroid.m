function [x,y,r,numberofcircles] = generateasteroid(numberofcircles)
% Returns x and y positions of each circle
% Accepts input of the number of circles
% Increments the number of circles each round by 1


if numberofcircles <= 35
numberofcircles = numberofcircles + 1; % Add a circle each level
end

r = 0.3; % Radius

% Stores all the x's and y's of each circle
x = 7.9*rand(1, numberofcircles) + 2; % No circles in the first 20% (x-wise)
y = 10*rand(1,numberofcircles)- 5;


end