function travel(amp, hstretch, x, hit_index, circlex, circley, score, highscore,sounds)
% Animates the light traveling through the path
% Accepts properties of the sin wave, asteroids, scores, and sound, as well
% as the 'hit_index'

    % Repeats until the light reaches the end of the path
    for i = 1:6:length(x)-6
        
        % Checks whether the light is close to the 'hit_index'
        if hit_index-3 <= i && i <= hit_index + 2
            
            % Plays hit sound
            sound(0.2*sounds{5},sounds{6})
            
            % Repeats for the flashing animation
            for e = 1:3
                
                % Flashes red
                % Calls the function trail
                trail(x,amp,hstretch,i,'r')
                redraw(x,amp,hstretch,circlex,circley,score,highscore,false)
                pause(0.15)
                
                % Flashes white
                trail(x,amp,hstretch,i,'w')
                redraw(x,amp,hstretch,circlex,circley,score,highscore,false)
                pause(0.15)
                
            end
            
            break

        end
        
        % Shows the next step of the light travel animation
        trail(x,amp,hstretch,i,'w')
        redraw(x,amp,hstretch,circlex,circley,score,highscore,false)
        pause(0.05)
        
    end
    
    % Redisplays all objects back to the screen
    redraw(x,amp,hstretch,circlex,circley,score,highscore,true)
    
end
