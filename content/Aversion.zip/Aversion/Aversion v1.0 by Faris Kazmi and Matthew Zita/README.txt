%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AVERSION v1.0
%
% By: Faris Kazmi and Matthew Zita
% 
% Acknowledgements: 
% 
% Almost all code was written independantly, with most extra knowledge coming
% from MATLAB's documentation and some from online
% 
% 
% Description:
% A game where you control the path of light to avoid asteroids!
% This game is optimized for high-end systems.
%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

How to test this program:

Un-zip the zip file into a folder. Make sure all content is inside the same folder.
You should have the following:

Aversion_main.m
AversionSoundtrack.m
check_for_collision.m
deathevent.m
draw_light_initial.m
drawcircle.m
generateasteroid.m
Hit.mp3
light.png
movement.m
PausingLightGame.m
README.txt
redraw.m
startup.m
sun.png
trail.m
travel.m
Travel.mp3

Load Aversion_main.m into MATLAB. Run the program. Sit back and enjoy!

WARNING:
Make sure MATLAB is running before opening Aversion_main.m.
Do not start MATLAB by clicking on the .m file.


